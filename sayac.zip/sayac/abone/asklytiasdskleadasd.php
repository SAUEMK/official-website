<?php 

error_reporting(0);
try{
	$db=new PDO("mysql:host=localhost;dbname=sayac_abone;charset=utf8", 'root','');
}

catch(PDOExpception $e){

echo $e->getMessage();

}

$ad=$_POST['abone_mail'];
                                   
$abonesor=$db->prepare("select * from aboneol");
$abonesor->execute();
while($abonecek=$abonesor->fetch(PDO::FETCH_ASSOC)){ 

if($abonecek['abone_mail']==$ad){

header("Location:../index.php?durum=mailkayitli");
return false;
}
}


if (isset($_POST['mailkaydet'])) {






$kaydet=$db->prepare("INSERT INTO aboneol SET 
abone_mail=:mail
");

$insert=$kaydet->execute(array(
'mail'=>$_POST['abone_mail']
));

if ($insert) {

	

header('Content-Type: text/html; charset=utf-8');
require 'PHPMailerAutoload.php';
$phpmailer = new PHPMailer;
$phpmailer->isSMTP();
$phpmailer->Host = 'mail.sauemk.com'; // duzenlenecek
$phpmailer->SMTPAuth = true;
$phpmailer->Username = 'noreply@sauemk.com'; // duzenlenecek
$phpmailer->Password = 'noreply123456'; // duzenlenecek
$phpmailer->SMTPSecure = 'tls'; // duzenlenecek
$phpmailer->Port = '587'; // duzenlenecek
$phpmailer->From = 'noreply@sauemk.com'; // duzenlenecek
$phpmailer->FromName = 'SAÜEMK'; // duzenlenecek
$phpmailer->AddReplyTo($ad, 'Yeni Üye');
$phpmailer->addAddress($ad, 'SAÜEMK'); // duzenlenecek
$phpmailer->isHTML(true);
$phpmailer->Subject = 'ERBİL BURAYI DÜZENLE(Mailin subjecti)';
$phpmailer->Body    = 'ERBİL BURAYI DÜZENLE(Mailin içeriği)';
$phpmailer->CharSet = 'UTF-8';
 
if(!$phpmailer->send()) {



} 

	Header("Location:../index.php?durum=ok&mmail=ok");

}
else{
	Header("Location:../index.php?durum=no");
}
}






 ?>
