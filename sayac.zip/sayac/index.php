<?php 
error_reporting(0); ?>

<!doctype html>
<html lang="en-US">


<!-- Mirrored from dev.premonday.com/arisn/p-comingsoon.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Jul 2017 13:16:48 GMT -->
<head>
    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>SAÜEMK</title>
    <meta name="keywords" content="" />
    <meta name="description" content="">
    <meta name="author" content="premonday.com">
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,400i|Poppins:300,400,500,600" rel="stylesheet">
    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon" />
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Vendor CSS -->
    <link rel="stylesheet" href="vendor/reset.css">
    <link rel="stylesheet" href="vendor/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/ion-icons/ionicons.min.css">
    <link rel="stylesheet" href="vendor/owl-slider/owl.carousel.css">
    <link rel="stylesheet" href="vendor/slideshow/slideshow.css">
    <link rel="stylesheet" href="vendor/lightbox/lity.min.css">
    <!-- Theme CSS -->
    <link id="theme" rel="stylesheet" href="css/theme01.css">
    <script src="vendor/modernizr.js"></script>
</head>

<body class="comingsoon">

    <!-- Scroll up -->
    <div class="scrollup">
        <i class="ion-ios-arrow-up"></i>
    </div>  

        <!-- Header -->
        <header id="neutral" class="center parallax-container dark" data-overlay="9">
            <div class="parallax"><img src="img/carousel/01.jpg" alt=""></div>
            <div class="header-in">
                <div class="caption">
                    <div class="container">
                        <div class="col-md-8 col-md-offset-2">
                            <h5>ÇOK YAKINDA</h5>
                            <h1>Sizler için yenileniyoruz!</h1>
                            <h6>Çok daha iyi bir website deneyimi için beklemede kalın</h6>
                            <h5>YAYINA KALAN SÜRE</h5>
                            <h2 id="getting-started"></h2>
                            <?php if ($_GET['durum']=='ok'&&$_GET['mmail']=='ok'){ ?>
                                <h2 style="text-align: center; text-decoration: none; display: inline-block; font-size: 16px; color: green;">Aramıza hoşgeldin, mailini kontrol etmeyi unutma!(Eğer mail gelen kutunuzda yoksa spam kutunuzu kontrol ediniz.)</h2>
                            <?php } 

                            else if($_GET['durum']=='mailkayitli'){
                                ?>
                                <h2 style="text-align: center; text-decoration: none; display: inline-block; font-size: 16px; color: green;">Mailiniz zaten kayıtlı. Şimdilik bizi sosyal medya hesaplarımızdan takip etmeye devam edin!</h2>
                            <?php
                            }

                            ?>

                            <hr>
                            <div id="c_newsletter">
                            
                                <form action="abone/asklytiasdskleadasd.php" name="abone_form" onsubmit="return check_register()" method="POST">
                                    <input name="abone_mail" type="mail" placeholder="E-posta adresiniz">
                                    <button style="background-color: #4CAF50; /* Green */
    border: none;
    color: white;
    padding: 12px 40px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;" type="submit" name="mailkaydet" class="btn green">Kaydet</button>
                                    <p class="note">*E-postanız reklam amaçlı kullanılmayacaktır</p>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <footer id="minimal" class="dark2 center">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <img src="img/logos/emk-logo.png" width="150" alt="">
                        <div class="social">
                            <a href="https://www.facebook.com/sakaryaemk/"><i class="ion-social-facebook"></i></a>
                            <a href="https://twitter.com/sakaryaemk"><i class="ion-social-twitter"></i></a>
                            <a href="https://www.instagram.com/sakaryaemk/"><i class="ion-social-instagram-outline"></i></a>
                            <a href="https://www.linkedin.com/company-beta/2290074"><i class="ion-social-linkedin-outline"></i></a>
                            <a href="https://plus.google.com/u/2/+SAUEMKTV"><i class="ion-social-googleplus"></i></a>
                            <a href="#"><i class="ion-social-snapchat"></i></a>
                            <a href="https://www.youtube.com/channel/UCQ47T-uDrRn5Vvp6WXY9n9A"><i class="ion-social-youtube"></i></a>
                            
                        </div>
                        <hr>
                        <p class="footer-text">2017 &copy; Sakarya Üniversite Endüstri Mühendisliği Kulübü. <br>Bu sitenin geliştirilmesi Bilişim & Medya Komisyonu tarafından yapılmıştır. Bütün hakları saklıdır. 
                        <br>Sitenin güncel versiyonu: ALPHA<br>
                    </div>
                </div>
            </div>
        </footer>

    </div>
    <!-- end of web-in -->
    <script src="vendor/jquery-2.2.1.min.js"></script>
    <script src="vendor/matchHeight-min.js"></script>
    <script src="vendor/contact/validator.js"></script>
    <script src="vendor/contact/contact.js"></script>
    <script src="vendor/pace.min.js"></script>
    <script src="vendor/headroom/headroom.min.js"></script>
    <script src="vendor/owl-slider/owl.carousel.min.js"></script>
    <script src="vendor/slideshow/anime.min.js"></script>
    <script src="vendor/slideshow/imagesloaded.pkgd.min.js"></script>
    <script src="vendor/slideshow/main.js"></script>
    <script src="vendor/parallax/materialize.min.js"></script>
    <script src="vendor/lightbox/lity.min.js"></script>
    <script src="vendor/tabs/jquery.tabslet.min.js"></script>
    <script src="vendor/masonry.pkgd.min.js"></script>
    <script src="js/main.min.js"></script>

    <!-- specific to this page -->
    <script src="vendor/countdown/jquery.countdown.min.js"></script>
    <script type="text/javascript">
    $("#getting-started")
        .countdown("2017/09/18", function(event) {
            $(this).text(
                event.strftime('%D gün %H:%M:%S')
            );
        });


    </script>
    <script type="text/javascript">
        
        function check_register(){
            var email = document.forms["abone_form"]["abone_mail"].value;
            var atpos=email.indexOf("@");
            var dotpos=email.lastIndexOf(".");

            
           

        if (email == "" || atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length) {
            alert("Lütfen geçerli bir email adresi giriniz.");
            return false;
        }else{

             return confirm('Onayladığınız anda sizde EMK ailesinin bir parçası olacaksınız. :)');
        }
        
       
    
        
        }
    </script>
</body>


<!-- Mirrored from dev.premonday.com/arisn/p-comingsoon.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 01 Jul 2017 13:16:49 GMT -->
</html>
